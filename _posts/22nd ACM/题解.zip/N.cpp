#include<bits/stdc++.h>
using namespace std;
const int N=1000005;
const int mod=998244353;
#define ll long long
int f[N];
int t,n,k;
inline int ksm(int x,int y)
{
	int ans=1;
	for (;y;y/=2,x=(ll)x*x%mod)
		if (y&1)
			ans=(ll)ans*x%mod;
	return ans;
}
inline void work()
{
	int n=1000000;
	f[1]=2;
	for (int i=2;i<=n;++i)
		f[i]=f[i-1]*2%mod;
	for (int i=1;i<=n;++i)
		for (int j=i*2;j<=n;j+=i)
			(f[j]+=mod-f[i])%=mod;
	for (int i=1;i<=n;++i)
		f[i]=(ll)f[i]*ksm(i,mod-2)%mod;
	for (int i=n;i>=1;--i)
		for (int j=i*2;j<=n;j+=i)
			(f[j]+=f[i])%=mod;
}
int main()
{
	work();
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d%d",&n,&k);
		printf("%d\n",f[__gcd(n,k)]);
	}
	return 0;
}
