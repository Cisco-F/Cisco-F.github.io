#pragma comment(linker, "/STACK:1024000000,1024000000")
/*
    Author: elfness@UESTC
*/
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>

using namespace std;
typedef long long LL;
typedef pair<int, int> PII;
#define PB push_back
#define fi first
#define se second
#define MP make_pair
const int ooo = 1000000000;
const LL oo = (LL) ooo * ooo;
const int P = 1000000007;
const int V = 100100;
const int M = 17;
vector<int> g[V];
LL a[V], b[V];
LL s[V];
int fa[V][M + 1];
LL C[V][M + 1];

void dfs(int u)  {
	s[u] = b[u];
	for (int i = 0; i < g[u].size(); ++i) {
		int v = g[u][i];
		dfs(v);
		s[u] += s[v];
	}
	if (fa[u][0] == -1) C[u][0] = oo;
	else C[u][0] = a[fa[u][0]] - s[u];
}

int L[V], R[V];
int _, n, Q;

int main() {
	scanf("%d", &_);
	while (_--) {
		scanf("%d%d", &n, &Q);
		for (int i = 1; i <= n; ++i) scanf("%lld%lld", &a[i], &b[i]);
		for (int i = 1; i <= n; ++i) g[i].clear();
		a[0] = a[n + 1] = oo;
		for (int i = 0; i <= n + 1; ++i) L[i] = i - 1;
		for (int i = 0; i <= n + 1; ++i) R[i] = i + 1;
		for (int i = 1; i <= n; ++i) {
			while (L[i] != 0 && a[L[i]] < a[i]) L[i] = L[L[i]];
		}
		for (int i = n; i >= 1; --i) {
			while (R[i] != n + 1 && a[R[i]] <= a[i]) R[i] = R[R[i]];
		}
		int root = -1;
		for (int i = 1; i <= n; ++i) {
			fa[i][0] = L[i];
			if (a[L[i]] > a[R[i]]) fa[i][0] = R[i];
			if (fa[i][0] != 0 && fa[i][0] != n + 1) g[fa[i][0]].PB(i);
			else root = i, fa[i][0] = -1;
		}
		dfs(root);
		for (int i = 1; i <= M; ++i) {
			for (int u = 1; u <= n; ++u) {
				if (fa[u][i - 1] == -1) C[u][i] = oo, fa[u][i] = -1;
				else C[u][i] = max(C[u][i - 1], C[fa[u][i - 1]][i - 1]), fa[u][i] = fa[fa[u][i - 1]][i - 1];
			}
		}
		for (int i = 0; i < Q; ++i) {
            int x;
            LL y, ans;
			scanf("%d%lld", &x, &y);
			if (a[x] > y) ans = y;
			else {
				for (int i = M; i >= 0; --i) {
					if (C[x][i] <= y) x = fa[x][i];
				}
				ans = s[x] + y;
			}
			printf("%lld\n", ans);
		}
	}
    return 0;
}

/*
2
6 5
3 6
1 2
9 10
2 2
7 1
4 2

2 1
3 1
3 9
4 5
6 4

6 5
3 6
1 2
13 10
2 2
7 1
4 3

2 1
3 1
3 9
4 5
6 4
*/
