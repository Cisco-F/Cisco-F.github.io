#include <bits/stdc++.h>

#define ll long long
#define ls id << 1
#define rs id << 1 | 1
#define mem(array, value, size) memset(array, value, ((size) + 5) * sizeof(decltype(array[0])))
#define memarray(array, value) memset(array, value, sizeof(array))
#define fillarray(array, value, begin, end) fill((array) + (begin), (array) + (end) + 1, value)
#define fillvector(v, value) fill((v).begin(), (v).end(), value)
#define pb(x) push_back(x)
#define st(x) (1LL << (x))
#define pii pair<int, int>
#define pll pair<ll, ll>
#define pil pair<int, ll>
#define pli pair<ll, int>
#define mp(a, b) make_pair((a), (b))
#define Flush fflush(stdout)
#define vecfirst (*vec.begin())
#define veclast (*vec.rbegin())
#define vecall(v) (v).begin(), (v).end()
#define vecupsort(v) (sort((v).begin(), (v).end()))
#define vecdownsort(v) (sort(vecall(v), greater<decltype(v.back())>()))
#define veccmpsort(v, cmp) (sort(vecall(v), cmp))
#define vecunique(v) ((v).resize(unique(vecall(v)) - (v).begin()))
using namespace std;
using db = long double;
const int N = 405;
const int inf = 0x3f3f3f3f;
const ll llinf = 0x3f3f3f3f3f3f3f3f;
const int mod = 998244353;
const int MOD = 1e9 + 7;
const db PI = acos(-1.0L);

int add(int a, int b) { return (a + b) >= mod ? a + b - mod : a + b; }

int sub(int a, int b) { return (a - b) < 0 ? a - b + mod : a - b; }

int mul(long long a, long long b) { return add(a * b % mod, mod); }

int ksm(long long a, long long b)
{
    long long ret = 1;
    while (b)
    {
        if (b & 1)
            ret = ret * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return ret;
}

const int MAXF = 3e5 + 50;

int fac[MAXF], invfac[MAXF];

int C(int n, int m)
{
    if (n < 0 || m < 0)
        return 0;
    return n < m ? 0 : mul(fac[n], mul(invfac[n - m], invfac[m]));
}

void init_comb()
{
    fac[0] = 1;
    for (int i = 1; i < MAXF; ++i)
        fac[i] = mul(fac[i - 1], i);
    invfac[MAXF - 1] = ksm(fac[MAXF - 1], mod - 2);
    for (int i = MAXF - 2; i >= 0; --i)
        invfac[i] = mul(invfac[i + 1], i + 1);
}

int f[N][N][N * 2];
int n, m, K;
char s[N][N];

inline void solve()
{
    cin >> n >> m >> K;
    for (int i = 1; i <= n; i++)
    {
        string str;
        cin >> str;
        for (int j = 1; j <= m; j++)
            s[i][j] = str[j - 1];
    }
    f[1][1][s[1][1] == 'A'] = f[1][1][0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
        {
            if (i == 1 && j == 1)
                continue;
            f[i][j][0] = C(i + j - 2, i - 1);
            if (s[i][j] == 'A')
            {
                for (int p = 1; p <= K; p++)
                    f[i][j][p] = add(f[i - 1][j][p - 1], f[i][j - 1][p - 1]);
            }
        }
    int ans = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
        {
            int res = C(n - 1 - (i - 1) + (m - 1 - (j - 1)), n - 1 - (i - 1));
            res = mul(res, f[i][j][K]);
            ans = add(ans, res);
        }
    ans = mul(ans, ksm(C(n + m - 2, n - 1), mod - 2));
    cout << ans << "\n";
}

int main()
{
    init_comb();
// #define MULTIPLE_CASE
#define CLOSE_IOS
#ifdef CLOSE_IOS
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
#endif
    int Test = 1;
#ifdef MULTIPLE_CASE
#ifdef CLOSE_IOS
    cin >> Test;
#else
    scanf("%d", &Test);
#endif
#endif
    while (Test--)
    {
        solve();
        // if (Test)
        //     putchar('\n');
    }
    return 0;
}