#include <bits/stdc++.h>
using namespace std;

int n,m,q;
struct node{
    int u,v,w;
    bool operator<(const node &rhs)const{
        return w<rhs.w;
    }
}p[1000005];
int ans[1000005];
struct que{
    int id,d,w;
    bool operator<(const que &rhs)const{
        return w<rhs.w;
    }
}ls[1000005];
int in[1000005],deg[1000005];
int c[1000005];
int lowbit(int x){
    return x&(-x);
}
void add(int x,int ch){
    while(x<=n){
        c[x]+=ch;
        x+=lowbit(x);
    }
}
int query(int x){
    int res=0;
    while(x){
        res+=c[x];
        x-=lowbit(x);
    }
    return res;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n>>m>>q;
    for(int i=1;i<=m;++i){
        cin>>p[i].u>>p[i].v>>p[i].w;
    }
    in[0]=n;
    sort(p+1,p+m+1);
    for(int i=1;i<=q;++i){
        cin>>ls[i].d>>ls[i].w;
        ls[i].id=i;
    }
    sort(ls+1,ls+q+1);
    int now=1;
    for(int i=1;i<=q;++i){
        while(p[now].w<=ls[i].w&&now<=m){
            in[deg[p[now].u]]--;
            if(deg[p[now].u])add(deg[p[now].u],-1);
            deg[p[now].u]++;
            in[deg[p[now].u]]++;
            if(deg[p[now].u])add(deg[p[now].u],1);
            in[deg[p[now].v]]--;
            if(deg[p[now].v])add(deg[p[now].v],-1);
            deg[p[now].v]++;
            in[deg[p[now].v]]++;
            if(deg[p[now].v])add(deg[p[now].v],1);
            now++;
        }
        ans[ls[i].id]=query(ls[i].d)+in[0];
    }
    for(int i=1;i<=q;++i)cout<<ans[i]<<'\n';
    return 0;
}
