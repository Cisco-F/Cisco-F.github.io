#include<cstdio>
#include<algorithm>
#include<set>
#include<cmath>
using namespace std;
 
int cmp; // 0 compare x , 1 compare slope .
const long double eps = 1e-14;
int sgn(long double x) {return (x > -eps) - (x < eps);}
struct Point {
    long double x,y,slop;
    int index;
    friend bool operator < (const Point &a,const Point &b) {
        if( !cmp ) return sgn(a.x - b.x) != 0 ? sgn(a.x - b.x) < 0 : sgn(a.y - b.y) < 0;
        //if( !cmp ) return a.x != b.x ? a.x < b.x : a.y < b.y;
		return a.slop < b.slop;
    }
    friend Point operator - (const Point &a,const Point &b) {
        return (Point){a.x-b.x,a.y-b.y};
    }
    friend double operator * (const Point &a,const Point &b) {
        return a.x * b.y - b.x * a.y;
    }
    inline double calc(double a,double b) const {
        return a * x + b * y;
    }
};

const int maxn = 1e6 + 5;
const int maxm = 1e6 + 5;
set<Point> st;
typedef pair<int, int > pii;
int n, m, u, v, ans[maxm], ot[maxm];
pii qs[maxm], proc[maxn];
 
inline void Pop_right(set<Point>::iterator nxt,const Point &p) {
    set<Point>::iterator lst;
    while(1) {
        lst = nxt , ++nxt;
        if( nxt == st.end() ) return;
        if( (*lst-p) * (*nxt-*lst) >= 0 ) return;
        st.erase(lst);
    }
}
inline void Pop_left(set<Point>::iterator prv,const Point &p) {
    set<Point>::iterator lst;
    while(prv!=st.begin()) {
        lst = prv , --prv;
        if( (*lst-*prv) * (p-*lst) >= 0 ) break;
        st.erase(lst);
    }
}
inline void insert(const Point &p) {
    cmp = 0;
    set<Point>::iterator prv,nxt,lst=st.lower_bound(p);
    if(lst!=st.begin()) {
		prv = lst, --prv;
		if((*lst - *prv) * (p - *prv) >= 0)
			return ;
	}
    if(lst!=st.begin()) Pop_left(--lst,p);
    lst=st.lower_bound(p);
    if(lst!=st.end()) Pop_right(lst,p);
    st.insert(p) , lst = st.find(p);
    if(lst!=st.begin()) {
        prv = lst , --prv;
        Point x = *prv;
        x.slop = ( p.y - x.y ) / ( p.x - x.x );
        st.erase(prv) , st.insert(x);
    }
    nxt = lst , ++nxt;
    if(nxt!=st.end()) {
        Point x = p , n = *nxt;
        x.slop = ( n.y - x.y ) / ( n.x - x.x );
        st.erase(lst) , st.insert(x);
    } else {
        Point x = p;
        x.slop = 1e18;
        st.erase(lst) , st.insert(x);
    }
}
inline int query(const long double k) {
    cmp = 1;
    set<Point>::iterator it = st.lower_bound((Point){0,0,k,-1}); // it can't be st.end() if st isn't empty .
    if( it==st.end() ) return 0;
    return it -> index;
}
 
int main() {
    scanf("%d", &n);
    for(int i = 1; i <= n; ++i) {
		scanf("%d%d", &u, &v);
		proc[i].first = u;
		proc[i].second = v;
	}
	sort(proc + 1, proc + n + 1);
	scanf("%d", &m);
	for(int i = 1; i <= m; ++i) {
		scanf("%d", &ot[i]);
		qs[i].first = ot[i];
		qs[i].second = i;
	}
	sort(qs + 1, qs + m + 1);
	int pos = 0;
	for(int l = 1; l <= m;) {
		int r = l, t = qs[l].first;
		while(r < m && qs[r].first == qs[r + 1].first) {
			++r;
		}
		while(pos < n && proc[pos + 1].first <= t) {
			++pos;
			long double x = (long double)1 / proc[pos].second;
			long double y = (long double)proc[pos].first / proc[pos].second;
			insert((Point) {x, y, 0.0, pos});
		}
		int nowans = query((long double)t / 1);
		for(int i = l; i <= r; ++i)
			ans[qs[i].second] = nowans;
		l = r + 1;
	}
	for(int i = 1; i <= m; ++i) {
		if(ans[i]) printf("%Lf\n", 1 + (long double)(ot[i] - proc[ans[i]].first) / proc[ans[i]].second);
		else printf("-1\n");
	}
    return 0;
}
