#include <cstdio>
#include <vector>
#include <algorithm>

using ull = unsigned long long;

int main()
{
	int n;
	scanf("%d", &n);
	std::vector<int> x(n), y(n);
	for (int i = 0; i < n; i++)
		scanf("%d %d", &x[i], &y[i]);
	std::vector<std::pair<ull, ull>> v;
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
		{
			ull mx = x[i] + x[j], my = y[i] + y[j];
			ull M = mx << 32 | my;
			ull l = 1LL * (x[i] - x[j]) * (x[i] - x[j]) + 1LL * (y[i] - y[j]) * (y[i] - y[j]);
			v.push_back({M, l});
		}
	std::sort(v.begin(), v.end());
	int ans = 0, c = 1;
	for (int i = 1; i < v.size(); i++, c++)
		if (v[i] != v[i - 1])
		{
			ans += c * (c - 1) / 2;
			c = 0;
		}
	printf("%d\n", ans);
	return 0;
}
