#include<bits/stdc++.h>
using namespace std;
//id type num
int it[7][7],in[7][7],nt[7][7];

int id[7],typ[7],num[7];

void init(){
	it[1][5]=-1;
	it[2][1]=it[2][2]=it[2][3]=it[2][4]=it[2][6]=-1;
	it[3][3]=it[3][5]=-1;
	it[4][4]=it[4][5]=-1;
	it[5][2]=it[5][3]=it[5][5]=-1;
	it[6][1]=it[6][2]=it[6][5]=-1;
	
	in[1][2]=in[1][5]=-1;
	in[2][1]=in[2][3]=in[2][4]=in[2][5]=in[2][6]=-1;
	in[3][2]=in[3][3]=-1;
	in[4][1]=in[4][2]=in[4][4]=in[4][5]=-1;
	in[5][2]=in[5][4]=-1;
	in[6][2]=in[6][4]=in[6][6]=-1;
	
	nt[1][4]=nt[1][5]=-1;
	nt[2][1]=nt[2][2]=nt[2][3]=nt[2][4]=nt[2][6]=-1;
	nt[3][1]=nt[3][3]=nt[3][4]=nt[3][5]=-1;
	nt[4][2]=nt[4][5]=-1;
	nt[5][5]=nt[5][6]=-1;
	nt[6][1]=nt[6][3]=nt[6][5]=-1;
}

int op[7][7],ti[7],ni[7],send[7],rec[7];

int chekku(){
	
	for(int i=1;i<=6;i++){
		if(it[id[i]][typ[i]]==-1||in[id[i]][num[i]]==-1||nt[num[i]][typ[i]]==-1)
			return 0;
	}
	
	for(int i=1;i<=6;i++){
		ti[typ[i]]=id[i];ni[num[i]]=id[i];
		send[i]=rec[i]=0;
		for(int j=1;j<=6;j++){
			op[i][j]=0;
		}
	}
	
	op[ni[6]][6]=op[6][ni[6]]=1;
	op[ti[1]][6]=op[6][ti[1]]=1;
	op[ti[1]][ni[6]]=op[ni[6]][ti[1]]=1;
	
	op[5][ni[4]]=op[5][ti[5]]=op[5][6]=1;
	op[ti[2]][ni[4]]=op[ti[2]][ti[5]]=op[ti[2]][6]=1;
	
	op[2][ni[1]]=op[2][ti[4]]=op[2][4]=1;
	op[ti[1]][ti[3]]=op[ti[2]][ti[3]]=op[ti[4]][ti[3]]=op[ti[5]][ti[3]]=op[ti[6]][ti[3]]=1;
	op[ti[1]][ni[3]]=op[ti[4]][ni[3]]=op[ti[5]][ni[3]]=1;
	op[1][ni[5]]=op[1][4]=1;
	op[ti[5]][ni[5]]=op[ti[5]][4]=1;
	
	op[ti[6]][2]=op[ni[5]][2]=1;
	
	op[ni[2]][3]=op[ti[5]][3]=1;
	op[3][ni[3]]=op[3][ni[6]]=1;
	
	for(int i=1;i<=6;i++){
		for(int j=1;j<=6;j++){
			send[i]+=op[i][j];
			rec[j]+=op[i][j];
		}
	}
	
	for(int i=1;i<=6;i++)if(op[i][i])return 0;
	
	if(send[5]>3)return 0;
	if(rec[5]>3)return 0;
	if(op[6][ti[2]])return 0;
	if(send[ti[2]]>3)return 0;
	if(send[2]>3)return 0;
	if(rec[2]>4)return 0;
	if(rec[ni[3]]>3)return 0;
	if(op[ni[3]][3]||op[ni[6]][3]||op[ni[3]][ni[6]])return 0;
	for(int i=1;i<=6;i++){
		if(op[i][4]+op[i][ni[4]]>1)return 0;
	}
	
	return 1;
}
char tid[6]={'F','R','I','S','K','Y'};
int main(){
	for(int i=1;i<=6;i++){
		id[i]=typ[i]=num[i]=i;
	}
	
	for(int i=1;i<=720;i++){
		for(int j=1;j<=720;j++){
			
			if(chekku()&&num[1]==4&&num[3]==5){
				for(int k=1;k<=6;k++){
					cout<<tid[k-1]<<typ[k]<<num[k]<<endl;
				}
			}
			next_permutation(num+1,num+7);
		}
		next_permutation(typ+1,typ+7);
	}
}
//114
//252
//345
//423
//566
//631

