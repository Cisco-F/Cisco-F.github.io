#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define cs const
#define pii pair<int,int>
#define fi first
#define se second
#define gc getchar
#define pb push_back
#define bg begin
inline int read(){
    char ch=gc();
    int res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
  inline ll readll(){
    char ch=gc();
    ll res=0,f=1;
    while(!isdigit(ch))f^=ch=='-',ch=gc();
    while(isdigit(ch))res=(res*10)+(ch^48),ch=gc();
    return f?res:-res;
}
template<typename tp>inline void chemx(tp &a,tp b){if(a<b)a=b;}
template<typename tp>inline void chemn(tp &a,tp b){if(a>b)a=b;}
cs int N=100005;
int main(){
    int n=read();
    cout<<1<<" "<<2*n-1<<'\n';
    return 0;
}
