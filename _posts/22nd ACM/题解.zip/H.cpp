#include <bits/stdc++.h>

#define ll long long
#define ls id << 1
#define rs id << 1 | 1
#define mem(array, value, size) memset(array, value, ((size) + 5) * sizeof(decltype(array[0])))
#define memarray(array, value) memset(array, value, sizeof(array))
#define fillarray(array, value, begin, end) fill((array) + (begin), (array) + (end) + 1, value)
#define fillvector(v, value) fill((v).begin(), (v).end(), value)
#define pb(x) push_back(x)
#define st(x) (1LL << (x))
#define pii pair<int, int>
#define pll pair<ll,ll>
#define pil pair<int,ll>
#define pli pair<ll,int>
#define mp(a, b) make_pair((a), (b))
#define Flush fflush(stdout)
#define vecfirst (*vec.begin())
#define veclast (*vec.rbegin())
#define vecall(v) (v).begin(), (v).end()
#define vecupsort(v) (sort((v).begin(), (v).end()))
#define vecdownsort(v) (sort(vecall(v), greater<decltype(v.back())>()))
#define veccmpsort(v, cmp) (sort(vecall(v), cmp))
#define vecunique(v) ((v).resize(unique(vecall(v))-(v).begin()))
using namespace std;
using db = long double;
const int N = 500050;
const int inf = 0x3f3f3f3f;
const ll llinf = 0x3f3f3f3f3f3f3f3f;
const int mod = 998244353;
const int MOD = 1e9 + 7;
const db PI = acos(-1.0L);

struct segtree {
    int l, r;
    int sum;
} t[N << 2];

void build(int l, int r, int id) {
    t[id].l = l, t[id].r = r;
    if (l == r) {
        t[id].sum = 1;
        return;
    }
    int mid = (l + r) / 2;
    build(l, mid, id << 1);
    build(mid + 1, r, id << 1 | 1);
    t[id].sum = (t[id << 1].sum + t[id << 1 | 1].sum);
}

void change(int pos, int val, int id) {
    int L = t[id].l, R = t[id].r;
    if (L == R) {
        t[id].sum += val;
        return;
    }
    int mid = (L + R) / 2;
    if (pos <= mid) change(pos, val, id << 1);
    else change(pos, val, id << 1 | 1);
    t[id].sum = (t[id << 1].sum + t[id << 1 | 1].sum);
}

int qpos, nowsum;

void query(int myv, int ql, int qr, int id) {
    if (ql > qr) return;
    int l = t[id].l, r = t[id].r;
    int mid = (l + r) / 2;
    if (l >= ql && r <= qr) {
        int sum = t[id].sum + nowsum;
        if (qpos) return;
        if (sum < myv) {
            nowsum = sum;
            return;
        }
        if (l == r) {
            if (myv > nowsum) nowsum += t[id].sum;
            if (myv == nowsum && !qpos) qpos = l;
            return;
        }
        int lsum = t[ls].sum + nowsum;
        if (lsum >= myv) {
            query(myv, ql, qr, ls);
        } else {
            nowsum = lsum;
            query(myv, ql, qr, rs);
        }
        return;
    }
    if (qr <= mid) {
        query(myv, ql, qr, ls);
    } else if (ql > mid) {
        query(myv, ql, qr, rs);
    } else {
        query(myv, ql, mid, ls);
        if (!qpos)
            query(myv, mid + 1, qr, rs);
    }
}

int n;
set<int> s;

int get_nxt(int nowid) {
    change(nowid, -1, 1);
    s.erase(nowid);
    auto it = s.lower_bound(nowid);
    if (it == s.end()) it = s.begin();
    nowid = *it;
    return nowid;
}

inline void solve() {
    int Q;
    cin >> n >> Q;
    build(1, n, 1);
    for (int i = 1; i <= n; i++) s.insert(i);
    int m = n;
    for (int test = 1, nowid = 1; test <= Q; test++, n--) {
        int k;
        cin >> k;
        if ((k - 1) % n == 0) {
            cout << nowid << "\n";
            nowid = get_nxt(nowid);
            continue;
        }
        k--;
        k %= n;
        qpos = nowsum = 0;
        query(k, nowid + 1, m, 1);
        k -= nowsum;
        if (k > 0) {
            nowsum = qpos = 0;
            query(k, 1, nowid - 1, 1);
            k -= nowsum;
        }
        assert(k == 0);
        assert(qpos != 0);
        nowid = get_nxt(qpos);
        cout << qpos << "\n";
    }
}

int main() {
//#define MULTIPLE_CASE
#define CLOSE_IOS
#ifdef CLOSE_IOS
    ios::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
#endif
    int Test = 1;
#ifdef MULTIPLE_CASE
#ifdef CLOSE_IOS
    cin >> Test;
#else
    scanf("%d", &Test);
#endif
#endif
    while (Test--) {
        solve();
        // if (Test)
        //     putchar('\n');
    }
    return 0;
}
