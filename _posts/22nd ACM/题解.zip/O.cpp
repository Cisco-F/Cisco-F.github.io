#include<bits/stdc++.h>
using namespace std;
#define cs const
#define re register
#define pb push_back
#define pii pair<int,int>
#define fi first
#define se second
#define bg begin
#define ll long long
cs int RLEN=1<<20|1;
#define gc getchar
inline int read(){
	char ch=gc();
	int res=0;bool f=1;
	while(!isdigit(ch))f^=ch=='-',ch=gc();
	while(isdigit(ch))res=(res+(res<<2)<<1)+(ch^48),ch=gc();
	return f?res:-res;
}
inline int readstring(char *s){
	int top=0;char ch=gc();
	while(!isalpha(ch))ch=gc();
	while(isalpha(ch))s[++top]=ch,ch=gc();
	return top;
}
template<class tp>inline void chemx(tp &a,tp b){a<b?a=b:0;}
template<class tp>inline void chemn(tp &a,tp b){a>b?a=b:0;}
cs int mod=998244353;
inline int add(int a,int b){return (a+b)>=mod?(a+b-mod):(a+b);}
inline int dec(int a,int b){return (a<b)?(a-b+mod):(a-b);}
inline int mul(int a,int b){static ll r;r=(ll)a*b;return (r>=mod)?(r%mod):r;}
inline void Add(int &a,int b){a=(a+b)>=mod?(a+b-mod):(a+b);}
inline void Dec(int &a,int b){a=(a<b)?(a-b+mod):(a-b);}
inline void Mul(int &a,int b){static ll r;r=(ll)a*b;a=(r>=mod)?(r%mod):r;}
inline int ksm(int a,int b,int res=1){for(;b;b>>=1,Mul(a,a))(b&1)&&(Mul(res,a),1);return res;}
inline int Inv(int x){return ksm(x,mod-2);}
inline int fix(ll x){x%=mod;return (x<0)?x+mod:x;}
cs int N=100005;
int n;
int a[N];
ll s[N];
void solve(){
    n=read();
    assert(1<=n&&n<=100000);
    for(int i=1;i<=n;i++){
        a[i]=read();
        assert(0<=a[i]&&a[i]<=1e9);
        s[i]=s[i-1]+a[i];
    }
    int cnt=0;
    ll vl=1;
    for(int i=1;i<=n;i++){
        if(vl<a[i]){
            ll x=1+s[i-1];
            ll x2=(a[i]-vl+x-1)/x;
            vl+=x2*x;
            cnt+=x2;
            vl+=a[i];
        }
        else{
            vl+=a[i];
        }
       // cout<<cnt<<'\n';
    }
    cout<<cnt<<'\n';
}
int main(){
    int T=1;
    while(T--)solve();
}
