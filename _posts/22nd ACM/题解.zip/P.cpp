#include <cstdio>
#include <vector>
#include <algorithm>
#include <functional>
#include <unordered_map>

void Solve()
{
	int n; scanf("%d", &n);
	std::unordered_map<long long, int> mp;
	int R = 0;
	std::vector<std::pair<int, int>> edges;
	for (int i = 0; i < n; i++)
	{
		int a, b, c; scanf("%d %d %d", &a, &b, &c);
		if (a > b) std::swap(a, b);
		if (a > c) std::swap(a, c);
		if (b > c) std::swap(b, c);
		std::function<int(int, int)> getID = [&](int a, int b)
		{
			long long p = (long long)a << 30 | b;
			auto it = mp.find(p); int res = R;
			if (it == mp.end())
				mp[p] = R++;
			else
				res = it -> second;
			return res;
		};
		edges.push_back({i, n + getID(a, b)});
		edges.push_back({i, n + getID(a, c)});
		edges.push_back({i, n + getID(b, c)});
	}
	std::vector<std::vector<int>> g(n + R);
	for (auto [x, y] : edges)
	{
		g[x].push_back(y); g[y].push_back(x);
	}
	std::vector<bool> vis(n + R, false);
	int ans = 0;
	std::vector<int> buc(n + 1, 0);
	for (int i = 0; i < n; i++)
		if (!vis[i])
		{
			std::function<int(int)> dfs = [&](int x)
			{
				vis[x] = true;
				int res = (x < n);
				for (int v : g[x]) if (!vis[v]) res += dfs(v);
				return res;
			};
			++buc[dfs(i)]; ++ans;
		}
	printf("%d\n", ans);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= buc[i]; j++)
			printf("%d ", i);
	putchar('\n');
	return ;
}

int main()
{
	int T; scanf("%d", &T);
	while (T--) Solve();
	return 0;
}
