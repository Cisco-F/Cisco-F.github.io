// std.cpp: model solution to 'whac-a-mole'
// Author: HeRaNO
// Method: implementation
// Time complexity: O(nk)
#include <cstdio>
#include <vector>

int main()
{
	int n, m, k;
	scanf("%d %d %d", &n, &m, &k);
	std::vector<std::vector<int>> g(n + 1, std::vector<int>());
	for (int i = 1; i <= m; i++)
	{
		int u, v; scanf("%d %d", &u, &v);
		g[u].push_back(v); g[v].push_back(u);
	}
	std::vector<int> ps(k);
	for (int i = 0; i < k; i++) scanf("%d", &ps[i]);
	if (m >= n)
		return puts("Lose"), 0;
	std::vector<bool> possiblities(n + 1, true);
	int turn = 1;
	for (int now : ps)
	{
		std::vector<bool> newPossi(n + 1, false);
		possiblities[now] = false;
		bool f = true;
		for (int i = 1; i <= n && f; i++)
			if (possiblities[i]) f = false;
		if (f)
			return printf("%d\n", turn), 0;
		for (int i = 1; i <= n; i++)
			if (possiblities[i])
			{
				for (int v : g[i]) newPossi[v] = true;
			}
		possiblities = newPossi; ++turn;
	}
	puts("Lose");
	return 0;
}
