#include <cstdio>
#include <vector>
#include <functional>

int main()
{
	int n;
	scanf("%d", &n);
	std::vector<std::vector<int>> g(n + 1);
	for (int i = 1; i < n; i++)
	{
		int u, v; scanf("%d %d", &u, &v);
		g[u].push_back(v); g[v].push_back(u);
	}
	std::vector<int> f(n + 1, 0);
	std::function<void(int, int)> dfs = [&](int x, int fa)
	{
		f[x] = fa;
		for (int v : g[x])
			if (v != fa) dfs(v, x);
		return ;
	};
	dfs(n, 0);
	for (int i = 1; i < n; i++)
		printf("%d%c", f[i], " \n"[i == n - 1]);
	return 0;
}
