#include <cstdio>
#include <iostream>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
const int N = 1e5 + 1;

int n, m, k, head[N], nxt[N << 1], to[N << 1], eid = 1;
void addedge(int u, int v){
    to[eid] = v;
    nxt[eid] = head[u];
    head[u] = eid++;
}

int dist[N];
int t[N], cntt[N], c[N], cntc[N];

vector<int> vec[N];

int main(){
    scanf("%d%d%d", &n, &m, &k);
    for (int u = 2; u <= n; u++){
        int v;
        scanf("%d", &v);
        addedge(u, v);
        addedge(v, u);
    }
    for(int i = 1; i <= m; i++)
        scanf("%d", &t[i]);
    memset(dist, -1, sizeof(dist));
    queue<int> q;
    for (int i = 1; i <= k; i++){
        scanf("%d", &c[i]);
        dist[c[i]] = 0;
        cntt[c[i]]++;
        q.push(c[i]);
    }
    while(q.size()){
        int u = q.front();
        q.pop();
        vec[dist[u]].push_back(u);
        for (int e = head[u]; e; e = nxt[e]){
            if(dist[to[e]] == -1){
                dist[to[e]] = dist[u] + 1;
                q.push(to[e]);
            }
            if(dist[to[e]] == dist[u] + 1)
                cntt[to[e]] += cntt[u];
        }
    }
    for(int i = 1; i <= m; i++){
        printf("%d ", cntt[t[i]]);
        cntc[t[i]]++;
    }
    putchar('\n');
    for (int i = n - 1; i > 0; i--)
        for(int u : vec[i])
            for(int e = head[u]; e; e = nxt[e])
                if(dist[u] == dist[to[e]] + 1)
                    cntc[to[e]] += cntc[u];
    for (int i = 1; i <= k; i++)
        printf("%d ", cntc[c[i]]);
    return 0;
}
