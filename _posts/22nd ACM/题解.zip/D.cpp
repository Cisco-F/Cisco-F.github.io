#include <bits/stdc++.h>
#define F(i, l, r) for (int i = (l), _end_ = (int)(r); i <= _end_; ++i)
#define f(i, r, l) for (int i = (r), _end_ = (int)(l); i >= _end_; --i)
#define Set(a, v) memset(a, v, sizeof(a))
#define File(a)                       \
    freopen("input.txt", "r", stdin); \
    freopen("output.txt", "w", stdout)
using namespace std;
bool chkmin(int& a, int b) { return b < a ? a = b, 1 : 0; }
bool chkmax(int& a, int b) { return b > a ? a = b, 1 : 0; }

map<int, int> g[200005];
int n;
void solve(int tc)
{
    cin >> n;
    for (int i = 1; i <= 200000;++i)
        g[i].clear();
    for (int i = 1; i <= n;++i){
        int x1, x2, y1, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        int tt = x1 + y1;
        g[tt][x1]++;
        g[tt][x2]--;
    }
    long long tot = 0;
    bool flag = 1;
   
    for (int i = 1; i <= 200000; ++i)
    {
        int pre = 0, st = -1;
        for(auto it:g[i]){
            pre += it.second;
            if(pre>1)
                flag = 0;
            if(pre==0)
                tot += it.first - st;
            if(pre>=1&&it.second==pre)
                st = it.first;
            //cout << it.first << " " << i << " " << st << endl;
        }
       // if(g[i].size())cout<<tot<<" "<<st<<" "<<i<<endl;
    }
    puts(flag ? "YES" : "NO");
    printf("%lld\n", tot);
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T = 1;
    cin >> T;
    for (int i = 1; i <= T; ++i) {
        solve(i);
    }
    return 0;
}

