#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int P = 1000000007, inv2 = (P + 1) / 2;
int add(int a, int b) { a += b; return a < P ? a : a - P; }
int sub(int a, int b) { a -= b; return a < 0 ? a + P : a; }
int mul(int a, int b) { return 1ll * a * b % P; }

template<int a, int b>
int solve1(ll n) {
    int ans = 0, i = 0;
    while (i < a && n >= 0) {
        ans = add(ans, n % a ? 0 : mul((n / (a * b) + 1) % P, sub((n / a + 1) % P, mul(n / (a * b) % P, mul(b, inv2)))));
        n -= b;
        i++;
    }
    return ans;
}

int solve0(ll n) {
    if (n % 2 != 0) n -= 9;
    n /= 2;
    return sub(add(solve1<9, 5>(n), solve1<9, 4>(n)), n % 9 != 0 ? 0 : (n / 9 + 1) % P);
}

int solve_bf(ll n) {
    ll res = 0;
    for (int x = 0; x * 8 <= n; ++ x)
        for (int y = 0; y * 9 + x * 8 <= n; ++y)
            if ((n - 8 * x - 9 * y) % 10 == 0)
                res++;
    return res;
}

int main(void) {
    int T; scanf("%d", &T);
    while (T--) {
        ll n;
        scanf("%lld", &n);
        printf("%d\n", solve0(n));
    }
    return 0;
}

